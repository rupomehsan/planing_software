export default class BaseBuilder {
    protected exportFile(dataType: string, fileName: string, data: string): void;
}
