export default interface IFileExporter {
    exportFile(): void;
}
